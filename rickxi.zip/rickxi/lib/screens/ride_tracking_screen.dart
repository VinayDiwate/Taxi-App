import 'package:flutter/material.dart';
import 'package:flutter_map/flutter_map.dart';
import 'package:latlong2/latlong.dart';

class RideTrackingScreen extends StatelessWidget {
  const RideTrackingScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      appBar: AppBar(
        title: const Text("Tracking Ride"),
        backgroundColor: Colors.yellowAccent,
        foregroundColor: Colors.black,
      ),
      body: Stack(
        children: [
          // 📍 Map Layer
          FlutterMap(
            options: MapOptions(
              initialCenter: LatLng(16.7050, 74.2433), // Kolhapur
              initialZoom: 14,
            ),
            children: [
              TileLayer(
                urlTemplate: 'https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png',
                subdomains: const ['a', 'b', 'c'],
              ),
              MarkerLayer(
                markers: [
                  Marker(
                    width: 50,
                    height: 50,
                    point: LatLng(16.7050, 74.2433),
                    child: const Icon(Icons.motorcycle, color: Colors.red, size: 35),
                  ),
                ],
              ),
            ],
          ),

          // 🟡 Bottom Ride Info Panel
          Align(
            alignment: Alignment.bottomCenter,
            child: Container(
              decoration: const BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.vertical(top: Radius.circular(30)),
              ),
              padding: const EdgeInsets.all(20),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  // 🚴 Driver Details
                  Row(
                    children: [
                      const CircleAvatar(
                        radius: 28,
                        backgroundImage: AssetImage('assets/images/driver_avatar.png'),
                      ),
                      const SizedBox(width: 15),
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: const [
                          Text('Rider: Rohit Patil', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
                          Text('Vehicle: MH09 AB 1234', style: TextStyle(color: Colors.grey)),
                        ],
                      ),
                      const Spacer(),
                      const Icon(Icons.phone, color: Colors.green),
                    ],
                  ),
                  const SizedBox(height: 20),

                  // 🕐 Status / ETA
                  Row(
                    children: const [
                      Icon(Icons.directions_bike, color: Colors.black),
                      SizedBox(width: 10),
                      Expanded(
                        child: Text(
                          "Your driver is arriving in 4 mins",
                          style: TextStyle(fontSize: 16, fontWeight: FontWeight.w500),
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 20),

                  // ❌ Cancel Ride
                  ElevatedButton.icon(
                    onPressed: () {
                      showDialog(
                        context: context,
                        builder: (_) => AlertDialog(
                          title: const Text("Cancel Ride"),
                          content: const Text("Are you sure you want to cancel this ride?"),
                          actions: [
                            TextButton(
                              onPressed: () => Navigator.pop(context),
                              child: const Text("No"),
                            ),
                            TextButton(
                              onPressed: () {
                                Navigator.popUntil(context, ModalRoute.withName('/home'));
                              },
                              child: const Text("Yes", style: TextStyle(color: Colors.red)),
                            ),
                          ],
                        ),
                      );
                    },
                    icon: const Icon(Icons.cancel),
                    label: const Text("Cancel Ride"),
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.red,
                      foregroundColor: Colors.white,
                      padding: const EdgeInsets.symmetric(horizontal: 40, vertical: 12),
                    ),
                  ),

                  const SizedBox(height: 10),

                  // ✅ Complete Ride Button (Navigate to Rating Screen)
                  ElevatedButton.icon(
                    onPressed: () {
                      Navigator.pushNamed(context, '/rate-ride');
                    },
                    icon: const Icon(Icons.check_circle),
                    label: const Text("Complete Ride"),
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.green,
                      foregroundColor: Colors.white,
                      padding: const EdgeInsets.symmetric(horizontal: 40, vertical: 12),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}
