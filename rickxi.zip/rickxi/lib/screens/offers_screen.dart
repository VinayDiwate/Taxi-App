import 'package:flutter/material.dart';

class OffersScreen extends StatelessWidget {
  const OffersScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      appBar: AppBar(
        title: const Text('Offers'),
        backgroundColor: Colors.black,
        foregroundColor: Colors.yellowAccent,
      ),
      body: ListView(
        padding: const EdgeInsets.all(20),
        children: const [
          Card(
            color: Colors.grey,
            child: ListTile(
              leading: Icon(Icons.local_offer, color: Colors.red),
              title: Text('Get 20% off on your next ride!'),
              subtitle: Text('Use code: RICKXI20'),
            ),
          ),
          Card(
            color: Colors.grey,
            child: ListTile(
              leading: Icon(Icons.local_offer, color: Colors.green),
              title: Text('₹50 Cashback on UPI Payment'),
              subtitle: Text('Valid till: 30 Apr 2025'),
            ),
          ),
        ],
      ),
    );
  }
}
