import 'package:flutter/material.dart';

class SupportScreen extends StatelessWidget {
  const SupportScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      appBar: AppBar(
        title: const Text('Support'),
        backgroundColor: Colors.black,
        foregroundColor: Colors.yellowAccent,
      ),
      body: Padding(
        padding: const EdgeInsets.all(20.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: const [
            Text(
              'Need Help?',
              style: TextStyle(color: Colors.white, fontSize: 20, fontWeight: FontWeight.bold),
            ),
            SizedBox(height: 20),
            Text('Email: support@rickxi.com', style: TextStyle(color: Colors.white)),
            SizedBox(height: 10),
            Text('Phone: +91 9876543210', style: TextStyle(color: Colors.white)),
            SizedBox(height: 30),
            Text(
              'We are available 24/7 to assist you.',
              style: TextStyle(color: Colors.white70),
            ),
          ],
        ),
      ),
    );
  }
}
