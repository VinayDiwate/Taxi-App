import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:rickxi/screens/ride_tracking_screen.dart';

class PersonalRideScreen extends StatefulWidget {
  const PersonalRideScreen({super.key});

  @override
  State<PersonalRideScreen> createState() => _PersonalRideScreenState();
}

class _PersonalRideScreenState extends State<PersonalRideScreen> {
  DateTime selectedDate = DateTime.now();
  int passengers = 1;
  final TextEditingController pickupController = TextEditingController();
  final TextEditingController dropController = TextEditingController();
  final TextEditingController priceController = TextEditingController(text: '100');

  Future<void> _pickDate() async {
    final DateTime? picked = await showDatePicker(
      context: context,
      initialDate: selectedDate,
      firstDate: DateTime.now(),
      lastDate: DateTime(2030),
    );
    if (picked != null) {
      setState(() {
        selectedDate = picked;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    final dateText = DateFormat('yyyy-MM-dd').format(selectedDate);

    return Scaffold(
      backgroundColor: Colors.black,
      appBar: AppBar(
        title: const Text('Personal Ride'),
        backgroundColor: Colors.yellowAccent,
        foregroundColor: Colors.black,
      ),
      body: Padding(
        padding: const EdgeInsets.all(20.0),
        child: Column(
          children: [
            _buildField('Pickup Location', pickupController),
            const SizedBox(height: 15),
            _buildField('Drop Location', dropController),
            const SizedBox(height: 15),
            ListTile(
              tileColor: Colors.white,
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(30)),
              title: Text('Date: $dateText', style: const TextStyle(fontWeight: FontWeight.bold)),
              trailing: const Icon(Icons.calendar_today),
              onTap: _pickDate,
            ),
            const SizedBox(height: 15),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                const Text('Passengers:', style: TextStyle(color: Colors.white, fontSize: 16)),
                Row(
                  children: [
                    IconButton(
                      onPressed: () {
                        if (passengers > 1) {
                          setState(() => passengers--);
                        }
                      },
                      icon: const Icon(Icons.remove, color: Colors.white),
                    ),
                    Text(
                      passengers.toString(),
                      style: const TextStyle(color: Colors.white),
                    ),
                    IconButton(
                      onPressed: () {
                        if (passengers < 4) {
                          setState(() => passengers++);
                        }
                      },
                      icon: const Icon(Icons.add, color: Colors.white),
                    ),
                  ],
                ),
              ],
            ),
            const SizedBox(height: 15),
            _buildField('Price (₹)', priceController),
            const SizedBox(height: 30),
            ElevatedButton(
              onPressed: () {
                showDialog(
                  context: context,
                  builder: (BuildContext context) {
                    return AlertDialog(
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                      title: const Text('Success', style: TextStyle(fontWeight: FontWeight.bold)),
                      content: const Text('Your ride is on its way!'),
                      actions: [
                        TextButton(
                          onPressed: () {
                            Navigator.pop(context); // Close dialog
                            Navigator.pushReplacement(
                              context,
                              MaterialPageRoute(builder: (_) => const RideTrackingScreen()),
                            );
                          },
                          child: const Text('OK'),
                        ),
                      ],
                    );
                  },
                );
              },
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.yellowAccent,
                foregroundColor: Colors.black,
                padding: const EdgeInsets.symmetric(horizontal: 50, vertical: 14),
              ),
              child: const Text('Book Now', style: TextStyle(fontWeight: FontWeight.bold)),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildField(String hint, TextEditingController controller) {
    return TextField(
      controller: controller,
      style: const TextStyle(color: Colors.black),
      decoration: InputDecoration(
        filled: true,
        fillColor: Colors.white,
        hintText: hint,
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(30),
          borderSide: BorderSide.none,
        ),
        contentPadding: const EdgeInsets.symmetric(horizontal: 20, vertical: 14),
      ),
    );
  }
}
