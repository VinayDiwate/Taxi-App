import 'package:flutter/material.dart';

class ProfileScreen extends StatelessWidget {
  const ProfileScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      appBar: AppBar(
        title: const Text('My Profile'),
        backgroundColor: Colors.black,
        foregroundColor: Colors.yellowAccent,
        actions: [
          IconButton(
            icon: const Icon(Icons.edit, color: Colors.yellowAccent),
            onPressed: () {
              // Add your edit logic here
              ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(content: Text("Edit Profile clicked")),
              );
            },
          ),
        ],
      ),
      body: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          children: [
            const CircleAvatar(
              radius: 50,
              backgroundColor: Colors.yellowAccent,
              child: Icon(Icons.person, size: 60, color: Colors.black),
            ),
            const SizedBox(height: 20),
            const Text(
              'Vinay Diwate',
              style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold, color: Colors.white),
            ),
            const SizedBox(height: 5),
            const Text('vinay@example.com', style: TextStyle(color: Colors.white70)),
            const SizedBox(height: 30),

            Card(
              color: Colors.grey[900],
              margin: const EdgeInsets.symmetric(vertical: 10),
              child: ListTile(
                leading: const Icon(Icons.phone, color: Colors.yellowAccent),
                title: const Text('Mobile', style: TextStyle(color: Colors.white)),
                subtitle: const Text('+91 9876543210', style: TextStyle(color: Colors.white70)),
              ),
            ),
            Card(
              color: Colors.grey[900],
              margin: const EdgeInsets.symmetric(vertical: 10),
              child: ListTile(
                leading: const Icon(Icons.location_on, color: Colors.yellowAccent),
                title: const Text('Address', style: TextStyle(color: Colors.white)),
                subtitle: const Text('Kolhapur, Maharashtra', style: TextStyle(color: Colors.white70)),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
