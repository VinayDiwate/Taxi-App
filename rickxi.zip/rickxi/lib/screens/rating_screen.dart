import 'package:flutter/material.dart';

class RatingScreen extends StatefulWidget {
  const RatingScreen({super.key});

  @override
  State<RatingScreen> createState() => _RatingScreenState();
}

class _RatingScreenState extends State<RatingScreen> {
  int selectedRating = 0;

  final List<Map<String, dynamic>> emojis = [
    {'icon': '😡', 'label': 'Angry'},
    {'icon': '😐', 'label': 'Okay'},
    {'icon': '😊', 'label': 'Happy'},
    {'icon': '😍', 'label': 'Loved it'},
  ];

  void submitRating() {
    // TODO: Save to backend here
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
        title: const Text("🎉 Thank You!", textAlign: TextAlign.center),
        content: const Text("We appreciate your feedback."),
        actions: [
          TextButton(
            onPressed: () {
              Navigator.popUntil(context, ModalRoute.withName('/home'));
            },
            child: const Text("Done"),
          )
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      appBar: AppBar(
        title: const Text('Rate Your Ride'),
        backgroundColor: Colors.yellowAccent,
        foregroundColor: Colors.black,
      ),
      body: Padding(
        padding: const EdgeInsets.all(24.0),
        child: Column(
          children: [
            const Text(
              'How was your ride?',
              style: TextStyle(color: Colors.white, fontSize: 22, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 30),

            // Emoji options
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: List.generate(emojis.length, (index) {
                return GestureDetector(
                  onTap: () {
                    setState(() {
                      selectedRating = index + 1;
                    });
                  },
                  child: Column(
                    children: [
                      Text(
                        emojis[index]['icon'],
                        style: TextStyle(
                          fontSize: 40,
                          color: selectedRating == index + 1 ? Colors.yellowAccent : Colors.white,
                        ),
                      ),
                      const SizedBox(height: 8),
                      Text(
                        emojis[index]['label'],
                        style: TextStyle(
                          color: selectedRating == index + 1 ? Colors.yellowAccent : Colors.white70,
                          fontWeight: selectedRating == index + 1 ? FontWeight.bold : FontWeight.normal,
                        ),
                      ),
                    ],
                  ),
                );
              }),
            ),

            const Spacer(),

            ElevatedButton(
              onPressed: selectedRating == 0 ? null : submitRating,
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.yellowAccent,
                foregroundColor: Colors.black,
                padding: const EdgeInsets.symmetric(horizontal: 40, vertical: 14),
              ),
              child: const Text('Submit', style: TextStyle(fontWeight: FontWeight.bold)),
            ),
          ],
        ),
      ),
    );
  }
}
