import 'package:flutter/material.dart';

class PaymentHistoryScreen extends StatelessWidget {
  const PaymentHistoryScreen({super.key});

  final List<Map<String, dynamic>> dummyPayments = const [
    {
      'date': '12 Apr 2025',
      'amount': '₹120',
      'method': 'UPI',
      'status': 'Paid',
    },
    {
      'date': '10 Apr 2025',
      'amount': '₹90',
      'method': 'Cash',
      'status': 'Paid',
    },
    {
      'date': '08 Apr 2025',
      'amount': '₹150',
      'method': 'UPI',
      'status': 'Paid',
    },
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      appBar: AppBar(
        title: const Text('Payment History'),
        backgroundColor: Colors.black,
        foregroundColor: Colors.yellowAccent,
      ),
      body: ListView.builder(
        padding: const EdgeInsets.all(16),
        itemCount: dummyPayments.length,
        itemBuilder: (context, index) {
          final payment = dummyPayments[index];
          return Card(
            color: Colors.grey[900],
            margin: const EdgeInsets.symmetric(vertical: 8),
            child: ListTile(
              leading: const Icon(Icons.payment, color: Colors.yellowAccent),
              title: Text(
                payment['amount'],
                style: const TextStyle(
                    color: Colors.white, fontWeight: FontWeight.bold),
              ),
              subtitle: Text(
                '${payment['date']} • ${payment['method']}',
                style: const TextStyle(color: Colors.grey),
              ),
              trailing: Text(
                payment['status'],
                style: const TextStyle(
                    color: Colors.green, fontWeight: FontWeight.bold),
              ),
            ),
          );
        },
      ),
    );
  }
}
