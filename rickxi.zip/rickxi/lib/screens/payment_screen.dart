import 'package:flutter/material.dart';

class PaymentScreen extends StatelessWidget {
  const PaymentScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      appBar: AppBar(
        backgroundColor: Colors.black,
        title: const Text(
          'Payment',
          style: TextStyle(color: Colors.yellowAccent),
        ),
        iconTheme: const IconThemeData(color: Colors.yellowAccent),
      ),
      body: Padding(
        padding: const EdgeInsets.all(20.0),
        child: Column(
          children: [
            // Ride fare box
            Container(
              width: double.infinity,
              padding: const EdgeInsets.all(20),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(10),
              ),
              child: const Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    "Amount to Pay",
                    style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                  ),
                  SizedBox(height: 10),
                  Text(
                    "₹ 120",
                    style: TextStyle(
                        fontSize: 24,
                        color: Colors.green,
                        fontWeight: FontWeight.bold),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 30),

            // Pay Now Button
            ElevatedButton(
              onPressed: () {
                showModalBottomSheet(
                  context: context,
                  backgroundColor: Colors.white,
                  shape: const RoundedRectangleBorder(
                    borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
                  ),
                  builder: (_) => const PaymentOptionsSheet(),
                );
              },
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.yellowAccent,
                foregroundColor: Colors.black,
                padding:
                    const EdgeInsets.symmetric(horizontal: 50, vertical: 14),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(4),
                ),
              ),
              child: const Text(
                "Pay Now",
                style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class PaymentOptionsSheet extends StatelessWidget {
  const PaymentOptionsSheet({super.key});

  void _handlePayment(BuildContext context, String method) {
    Navigator.pop(context); // Close BottomSheet
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text("You chose $method")),
    );

    Future.delayed(const Duration(milliseconds: 500), () {
      Navigator.pushNamed(context, '/tracking');
    });
  }

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(20),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          const Text(
            "Choose Payment Method",
            style: TextStyle(fontWeight: FontWeight.bold, fontSize: 18),
          ),
          const SizedBox(height: 20),
          ListTile(
            leading: const Icon(Icons.money, color: Colors.green),
            title: const Text("Cash"),
            onTap: () => _handlePayment(context, "Cash"),
          ),
          ListTile(
            leading: const Icon(Icons.qr_code, color: Colors.deepPurple),
            title: const Text("UPI"),
            onTap: () => _handlePayment(context, "UPI"),
          ),
        ],
      ),
    );
  }
}
