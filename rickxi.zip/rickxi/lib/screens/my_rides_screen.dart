import 'package:flutter/material.dart';

class MyRidesScreen extends StatelessWidget {
  const MyRidesScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      appBar: AppBar(
        title: const Text('My Rides'),
        backgroundColor: Colors.black,
        foregroundColor: Colors.yellowAccent,
      ),
      body: ListView.builder(
        itemCount: 5, // dummy 5 rides
        itemBuilder: (context, index) {
          return Card(
            margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
            color: Colors.grey[900],
            child: ListTile(
              leading: const Icon(Icons.local_taxi, color: Colors.yellowAccent),
              title: Text(
                'Ride ${index + 1}',
                style: const TextStyle(color: Colors.white),
              ),
              subtitle: const Text(
                'Pickup to Drop',
                style: TextStyle(color: Colors.white70),
              ),
              trailing: const Text(
                '₹120',
                style: TextStyle(color: Colors.greenAccent),
              ),
            ),
          );
        },
      ),
    );
  }
}
