import 'package:flutter/material.dart';

class FeedbackPopup extends StatefulWidget {
  const FeedbackPopup({super.key});

  @override
  State<FeedbackPopup> createState() => _FeedbackPopupState();
}

class _FeedbackPopupState extends State<FeedbackPopup> {
  int selectedStars = 0;
  final TextEditingController commentController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      title: const Text("Rate Your Ride"),
      content: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: List.generate(
              5,
              (index) => IconButton(
                icon: Icon(
                  Icons.star,
                  color: index < selectedStars ? Colors.orange : Colors.grey,
                ),
                onPressed: () {
                  setState(() {
                    selectedStars = index + 1;
                  });
                },
              ),
            ),
          ),
          TextField(
            controller: commentController,
            maxLines: 3,
            decoration: const InputDecoration(
              hintText: "Leave a comment...",
              border: OutlineInputBorder(),
            ),
          ),
        ],
      ),
      actions: [
        TextButton(
          onPressed: () => Navigator.pop(context),
          child: const Text("Cancel"),
        ),
        ElevatedButton(
          onPressed: () {
            Navigator.pop(context);
            ScaffoldMessenger.of(context).showSnackBar(
              const SnackBar(content: Text("Thanks for your feedback!")),
            );
          },
          style: ElevatedButton.styleFrom(backgroundColor: Colors.black),
          child: const Text("Submit", style: TextStyle(color: Colors.white)),
        )
      ],
    );
  }
}
